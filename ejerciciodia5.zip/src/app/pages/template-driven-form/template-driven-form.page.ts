import { Component } from '@angular/core';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.page.html',
  styleUrls: ['./template-driven-form.page.scss'],
})
export class TemplateDrivenFormPage {

  public name = 'Posti';

  constructor() {

  }
}
