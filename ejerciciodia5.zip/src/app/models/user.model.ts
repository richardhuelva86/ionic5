export interface User {
  id?: number;
  name: string;
  birthDate: string;
  sex: string;
  phone: number;
  email: string;
}
