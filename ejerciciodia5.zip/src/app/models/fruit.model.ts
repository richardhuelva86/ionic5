export interface Fruit {
  id: number;
  name: string;
  image: string;
  description: string;
  link?: string;
}
